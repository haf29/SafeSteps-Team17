AWS_REGION = "eu_north-1"
COGNITO_USER_POOL_ID = "eu-north-1_JFRxEAmcx"
COGNITO_APP_CLIENT_ID = "v4ao3kdsb3i56cq2fd8tbi5oa"

